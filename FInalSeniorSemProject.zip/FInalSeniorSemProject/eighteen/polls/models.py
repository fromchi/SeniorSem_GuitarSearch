from django.db import models

# Create your models here.

#this class configures exactly how your sqlite table will be with the fields you want

class ItemData(models.Model):
    name = models.CharField(max_length=500)
    url = models.CharField(max_length=2000)
    picture_link = models.CharField(max_length=2000)
    price = models.CharField(max_length=20)
    description = models.CharField(max_length=2000)
    tag = models.CharField(max_length=50)