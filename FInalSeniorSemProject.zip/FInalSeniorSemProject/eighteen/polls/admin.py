from django.contrib import admin

#configures the models to the database connected to the products
#cmd in the project folder to configure:
    #python manage.py makemigrations polls (sucess message)
    #python manage.py migrate (no news good news)

from .models import ItemData
admin.site.register(ItemData)