from django.shortcuts import render, redirect
from .models import ItemData
from django.contrib import messages
#from django.core.paginator import paginator

# Create your views here.
from django.core.paginator import Paginator
from django.http import HttpResponse
from .models import ItemData


def grid(request):
    if 'q' in request.GET:
        q=request.GET['q']
        
        if q == 'lowest':
            user_list = ItemData.objects.all()\
                .extra({'price': "CAST(price as DoubleField)"}) \
                .order_by('price')
        else:
            user_list = ItemData.objects.filter(name__contains=q)
            
            if not user_list :
                user_list  = ItemData.objects.filter(tag__contains=q)
                
                if not user_list:
                    user_list  = ItemData.objects.filter(description__contains=q)
            
            page = request.GET.get('page', 1)
            paginator = Paginator(user_list, 15)
            users = paginator.page(page)
            return render(request, 'grid.html', { 'users': users })
    
    elif 'lowest' in request.GET:
        user_list = ItemData.objects.all()\
                .extra({'price': "CAST(price as DoubleField)"}) \
                .order_by('price')
    else:
        user_list = ItemData.objects.all()

    page = request.GET.get('page', 1)
    paginator = Paginator(user_list, 15)
    
    try:
        users = paginator.page(page)
    
    except PageNotAnInteger:
        users = paginator.page(1)
    
    except EmptyPage:
        users = paginator.page(paginator.num_pages)
    

    return render(request, 'grid.html', { 'users': users })
