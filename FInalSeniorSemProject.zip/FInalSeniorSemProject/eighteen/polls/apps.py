from django.apps import AppConfig

"""defualt configuration when the polls application was created"""
class PollsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'polls'
