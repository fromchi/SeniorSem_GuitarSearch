from django.urls import path

from . import views
"""this is a path needed to link to urls.py within the eighteen folder/main folder of the program """
urlpatterns = [
    #Leave as empty string for base url
	path('', views.grid, name="grid"),

]