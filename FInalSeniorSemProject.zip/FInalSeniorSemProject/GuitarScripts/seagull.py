import helperFuncts
import requests
from bs4 import BeautifulSoup
import pandas
import scrapy
from collections import Counter 
import statistics
from statistics import mode
import guitarobj
from urllib.request import Request, urlopen


headers = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'
}

def get_data_links_seagull():
    s = []
    productlinks = []
    site= "https://seagullguitars.com/product-category/guitars/"
    hdr = {'User-Agent': 'Mozilla/5.0'}
    req = Request(site,headers=hdr)
    page = urlopen(req)
    soup = BeautifulSoup(page, 'lxml')
    s = soup.find_all('ul', class_ = 'products columns-4')
    for item in s:
        for link in item.find_all('a', href=True):
            productlinks.append(link['href'])
    return productlinks



def parse_links_seagull(productlinks):
    dict_guitar = []
    for x in productlinks:
        hdr = {'User-Agent': 'Mozilla/5.0'}
        req = Request(x,headers=hdr)
        page = urlopen(req)
        soup = BeautifulSoup(page, 'lxml')
        title = helperFuncts.title_price_null_check(soup.find('h1', class_='product_title entry-title'))
        pic_link =  soup.find('div', class_ ='image-zoom').find('img', class_ = 'img-responsive')['src']
        price = helperFuncts.title_price_null_check(soup.find('span', class_='woocommerce-Price-amount amount'))
        description = helperFuncts.title_price_null_check(soup.find('div', class_='woocommerce-Tabs-panel woocommerce-Tabs-panel--description panel entry-content wc-tab').find('p'))  
        dict_guitar.append(guitarobj.Guitar(x, price, title, pic_link, description,'seagull'))
    return dict_guitar