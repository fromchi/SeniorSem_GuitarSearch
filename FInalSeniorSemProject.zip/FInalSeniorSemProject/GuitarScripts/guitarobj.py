"""Object that holds the data parsed in the webscraping scripts"""

class Guitar:
  def __init__(self, url, cost, name, picture, description, tag):
    self.url = url
    self.cost = cost
    self.name = name
    self.picture = picture
    self.description = description
    self.tag = tag

  def print(self):
    print("{" +self.name + ", "+ self.cost + ",\n"+ self.url+ ",\n"+ self.picture+ "}")