import helperFuncts
import requests
from bs4 import BeautifulSoup
import pandas
import scrapy
from collections import Counter 
import statistics
from statistics import mode
import guitarobj
from urllib.request import Request, urlopen



"""base url needed to be added with individual link url for the links parsed"""
base_fender = 'https://www.fender.com'
base2_fender = 'https://shop.fender.com'

headers = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'
}


"""returns a list of links for all guitars on the page"""
def get_data_links_fender():
    productlinks = []
    r = requests.get(f'https://shop.fender.com/on/demandware.store/Sites-Fender-Site/en_US/Search-UpdateGrid?q=guitar&prefn1=type&prefv1=Acoustic%20Guitars%7cAcoustic%7cElectric%20Guitars&start=12&sz=1000')
    soup = BeautifulSoup(r.content, 'lxml')
    productlist = soup.find_all('body')
    for item in productlist:
        for link in item.find_all('a', class_  = 'product-tile-image', href=True):
            productlinks.append(base2_fender+link['href'])
    return productlinks


"""grabs the list of links and find individual feilds for each guitar in list"""
def parse_links_fender(productlinks):
    dict_guitar = []
    for links in productlinks:
        r = requests.get(links, headers=headers)
        soup = BeautifulSoup(r.content, 'lxml')
        title = helperFuncts.title_price_null_check(soup.find('h1', class_='product-name'))
        pic_link = helperFuncts.pic_link_find_check(soup.find('div', class_='magic-zoom-container main'))
        price = helperFuncts.title_price_null_check(soup.find('span', class_='value'))
        description = helperFuncts.title_price_null_check(soup.find('div', class_='row long-description').find('p'))
        dict_guitar.append(guitarobj.Guitar(links, price, title, pic_link, description ,"fender"))
    return dict_guitar