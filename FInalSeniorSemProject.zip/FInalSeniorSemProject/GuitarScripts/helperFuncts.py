import requests
from bs4 import BeautifulSoup
import pandas
import scrapy
from collections import Counter 
import statistics
from statistics import mode
import guitarobj
from urllib.request import Request, urlopen


headers = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'
}

"""formats fields to rid of whitespace"""
def title_price_null_check(tp):
    if tp is not None:
        return tp.text.strip()
    else:
        return None

"""checks the link field for null"""
def pic_link_find_check(pic_link):
    if pic_link is not None:
        for link in pic_link.find_all('a'):
            return link.get('href')
    else:
        return None

"""checks the picture link for null values"""
def pic_link_find_check_gg(pic_link):
    if pic_link is not None:
        for link in pic_link.find_all('img'):
            return link.get('src')
    else:
        return None
