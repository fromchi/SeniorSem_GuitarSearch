import json
import guitarobj
import seagull
import fender
import guitarx2
import guitarcenter

"""run the webscraping scripts"""
gc = guitarcenter.get_data_links_gc()
datagc = guitarcenter.parse_links_gc(gc)
fender = fender.get_data_links_fender()
datafender = guitarcenter.parse_links_fender(fender)
gx2 = guitarx2.get_data_links_guitarx2()
datagx2 = guitarx2.parse_links_guitar(gx2)
seagull = seagull.get_data_links_seagull()
dataseagull = seagull.parse_links_seagull(seagull)

"""compile a single list to get ready to parse into json"""
datalist = datagc + datafender + datagx2 + dataseagull

my_json = []

with open('guitar_objects_data.json', 'w') as f:
  for l in diction:
    """proper json configuration to load into sqlite db"""
    dict_data = {
        "model":"polls.ItemData",
        "fields":{
        "name": l.name,
        "url": l.url,
        "picture_link": l.picture,
        "price": l.cost,
        "description" : l.description,
        "tag": l.tag,
        }
    }
    my_json.append(dict_data)
  json.dump(my_json, f, indent=4)

