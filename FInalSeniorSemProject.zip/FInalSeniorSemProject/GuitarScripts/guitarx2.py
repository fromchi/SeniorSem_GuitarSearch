import helperFuncts
import requests
from bs4 import BeautifulSoup
import pandas
import scrapy
from collections import Counter 
import statistics
from statistics import mode
import guitarobj
from urllib.request import Request, urlopen

base_guitarx2 = 'https://www.guitarguitar.co.uk'
headers = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'
}

def get_data_links_guitarx2():
    s = []
    for x in range(0,3):
        if x < 2:
            r = requests.get(f'https://www.guitarguitar.co.uk/search/?Query=guitars&Filters.Ordering=7&Filters.CategoryBranch=guitars&Filters.MinPrice=&Filters.MaxPrice=')
        else:
            r = requests.get(f'https://www.guitarguitar.co.uk/search/page-{x}/?Query=guitars&Filters.Ordering=7&Filters.CategoryBranch=guitars&Filters.MinPrice=&Filters.MaxPrice=')

        soup = BeautifulSoup(r.content, 'lxml')
        productlist = soup.find_all('div', class_= 'products')
        for item in productlist:
            for link in item.find_all('a', href=True):
                s.append(base_guitarx2+link['href'])
    return s


def parse_links_guitarx2(productlinks):
    dict_guitar = []
    for links in productlinks:
        r = requests.get(links, headers=headers)
        soup = BeautifulSoup(r.content, 'lxml')        
        title = helperFuncts.title_price_null_check(soup.find('div', class_='product-intro').find('h1'))
        pic_link = helperFuncts.pic_link_find_check_gg(soup.find('div', class_='spotlight-item js-spotlight-item js-launch-photoswipe js-open-lightbox active'))
        price = helperFuncts.title_price_null_check(soup.find('p', class_='product-price'))
        description = helperFuncts.title_price_null_check(soup.find('div', class_='description-full').find('div').find('p'))
        dict_guitar.append(guitarobj.Guitar(links, price, title, pic_link, description, "guitarguitar"))
    return dict_guitar