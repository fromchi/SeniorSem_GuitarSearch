import requests
from bs4 import BeautifulSoup
import pandas
import scrapy
from collections import Counter 
import statistics
from statistics import mode
import guitarobj
from urllib.request import Request, urlopen
import helperFuncts

base_gc = 'https://www.guitarcenter.com'
base2_gc = 'https://www.guitarcenter.com/Guitars.gc'

headers = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'
}

def get_data_links_gc():
    productlinks = []
    for x in range(0,1):
        r = requests.get(f'https://www.guitarcenter.com/Guitars.gc#pageName=department-page&N=18144&Nao={x*30}&recsPerPage=30&postalCode=48231&radius=100&profileCountryCode=US&profileCurrencyCode=USD')
        soup = BeautifulSoup(r.content, 'lxml')
        productlist = soup.find_all('div', class_= 'productTitle')
        for item in productlist:
            for link in item.find_all('a', href=True):
                productlinks.append(base_gc+link['href'])
    return productlinks

def parse_links_gc(productlinks):
    dict_guitar = []
    for links in productlinks:
        r = requests.get(links, headers=headers)
        soup = BeautifulSoup(r.content, 'lxml')
        title = helperFuncts.title_price_null_check(soup.find('div', class_='titleWrap'))
        pic_link = helperFuncts.pic_link_find_check(soup.find('div', class_='top-info'))
        price = helperFuncts.title_price_null_check(soup.find('span', class_='topAlignedPrice'))
        description = helperFuncts.title_price_null_check(soup.find('p', attrs={'class' : 'description'}))
        dict_guitar.append(guitarobj.Guitar(links, price, title, pic_link, description, "guitarcenter"))
    return dict_guitar